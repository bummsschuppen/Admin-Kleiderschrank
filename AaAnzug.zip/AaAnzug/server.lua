ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


ESX.RegisterServerCallback('adminTablet:isAdmin', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer and xPlayer.getGroup() == 'admin' then
        cb(true)
    else
        cb(false)
    end
end)


RegisterNUICallback('wearSuit', function(_, cb)
    local src = source
    TriggerClientEvent('adminTablet:wearSuit', src)
    cb('ok')
end)


RegisterNUICallback('wearSkin', function(_, cb)
    local src = source
    TriggerClientEvent('adminTablet:wearSkin', src)
    cb('ok')
end)


RegisterNUICallback('showRank', function(data, cb)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer then
        local rank = data.rank or xPlayer.job.grade_label or xPlayer.getGroup()
        TriggerClientEvent('adminTablet:showRank', -1, src, rank)
    end
    cb('ok')
end)


RegisterNUICallback('hideRank', function(_, cb)
    local src = source
    TriggerClientEvent('adminTablet:hideRank', -1, src)
    cb('ok')
end)
