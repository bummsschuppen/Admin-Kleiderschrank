const tablet = document.getElementById('tablet');
const closeBtn = document.getElementById('closeTablet');
const wearSuitBtn = document.querySelector('#wearSuitCard button');
const wearSpecialBtn = document.querySelector('#wearSpecialCard button');
const showAdminBtn = document.getElementById('showAdminBtn');
const showHighBtn = document.getElementById('showHighBtn');
const showOwnerBtn = document.getElementById('showOwnerBtn');
const hideRankBtn = document.getElementById('hideRankBtn');
const notification = document.getElementById('notification');

let currentRank = null;


window.addEventListener('message', (event) => {
    if(event.data.action === 'openTablet') {
        tablet.classList.remove('hidden');
    }
});

closeBtn.addEventListener('click', () => {
    tablet.classList.add('hidden');
    fetch(`https://${GetParentResourceName()}/closeTablet`, { method:'POST' });
});


document.addEventListener('keydown', e => { if(e.key === "Escape") closeBtn.click(); });


wearSuitBtn.addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/wearSuit`, { method:'POST' })
        .then(() => showNotification("Adminanzug angezogen!"));
});


wearSpecialBtn.addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/wearSkin`, { method:'POST' })
        .then(() => showNotification("Altes Outfit angezogen!"));
});


function showRank(rank) {
    fetch(`https://${GetParentResourceName()}/showRank`, {
        method: 'POST',
        body: JSON.stringify({ rank: rank })
    });
    currentRank = rank;
    showNotification(`Rang ${rank} wird angezeigt!`);
}


function hideRank() {
    fetch(`https://${GetParentResourceName()}/hideRank`, { method: 'POST' });
    currentRank = null;
    showNotification("Rang ausgeblendet!");
}


showAdminBtn.addEventListener('click', () => showRank("ADMIN"));
showHighBtn.addEventListener('click', () => showRank("HIGH"));
showOwnerBtn.addEventListener('click', () => showRank("OWNER"));
hideRankBtn.addEventListener('click', () => hideRank());


function showNotification(text){
    notification.textContent = text;
    notification.classList.remove('hidden');
    setTimeout(()=>notification.classList.add('hidden'),1500);
}


setTick(() => {
    if(currentRank) {
        const playerPed = PlayerPedId();
        const coords = GetEntityCoords(playerPed);
        DrawText3D(coords[0], coords[1], coords[2] + 1.0, currentRank);
    }
});


function DrawText3D(x, y, z, text){
    const [onScreen, _x, _y] = World3dToScreen2d(x, y, z);
    if (onScreen) {
        SetTextScale(0.35, 0.35);
        SetTextFont(4);
        SetTextProportional(1);
        SetTextColour(255,0,0,215);
        SetTextCentre(true);
        SetTextEntry("STRING");
        AddTextComponentString(text);
        DrawText(_x,_y);
    }
}

document.getElementById('showAdminBtn').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/showRank`, { 
        method: 'POST', 
        body: JSON.stringify({ rank: "ADMIN" }) 
    }).then(() => showNotification("Rang ADMIN angezeigt!"));
});

document.getElementById('showHighBtn').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/showRank`, { 
        method: 'POST', 
        body: JSON.stringify({ rank: "HIGH" }) 
    }).then(() => showNotification("Rang HIGH angezeigt!"));
});

document.getElementById('showOwnerBtn').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/showRank`, { 
        method: 'POST', 
        body: JSON.stringify({ rank: "OWNER" }) 
    }).then(() => showNotification("Rang OWNER angezeigt!"));
});

document.getElementById('hideRankBtn').addEventListener('click', () => {
    fetch(`https://${GetParentResourceName()}/hideRank`, { method: 'POST' })
        .then(() => showNotification("Rang ausgeblendet!"));
});

