fx_version 'cerulean'
game 'gta5'

author 'BenGX'
description 'Admin Kleiderschrank'
version '1.0.0'

lua54 'yes'

client_scripts {
    'client.lua'
}

server_scripts {
    'server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/icons/admin.png',
    'html/icons/high.png',
    'html/icons/owner.png',
    'html/icons/hide.png',
    'html/icons/suit.png',
    'html/icons/zivi.png',
    'html/icons/close.png'
}