ESX = nil
local isTabletOpen = false
local savedSkin = nil
local rankPlayers = {}


Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(0)
    end

    
    RegisterCommand('kleiderschrank', function()
        ESX.TriggerServerCallback('adminTablet:isAdmin', function(isAdmin)
            if isAdmin and not isTabletOpen then
                SetNuiFocus(true, true)
                SendNUIMessage({ action = 'openTablet' })
                isTabletOpen = true
            elseif not isAdmin then
                ESX.ShowNotification("Du bist kein Admin!")
            end
        end)
    end)
end)


RegisterNUICallback('closeTablet', function(_, cb)
    SetNuiFocus(false, false)
    isTabletOpen = false
    cb('ok')
end)


RegisterNUICallback('wearSuit', function(_, cb)
    TriggerEvent('skinchanger:getSkin', function(skin)
        savedSkin = skin
        local outfit = {
            tshirt_1 = 15, tshirt_2 = 0,
            torso_1 = 287, torso_2 = 6,
            pants_1 = 114, pants_2 = 0,
            shoes_1 = 78, shoes_2 = 0,
            arms = 99,
            helmet_1 = 8, helmet_2 = 0
        }
        TriggerEvent('skinchanger:loadClothes', skin, outfit)
        ESX.ShowNotification("Adminanzug angezogen!")

        
        local playerPed = PlayerPedId()
        if DoesEntityExist(playerPed) then
            SetEntityInvincible(playerPed, true)
        end
    end)
    cb('ok')
end)


RegisterNUICallback('wearSkin', function(_, cb)
    if savedSkin then
        TriggerEvent('skinchanger:loadSkin', savedSkin)
        ESX.ShowNotification("Altes Outfit angezogen!")

        local playerPed = PlayerPedId()
        if DoesEntityExist(playerPed) then
            SetEntityInvincible(playerPed, false)
        end
    else
        ESX.ShowNotification("Kein vorheriges Outfit gespeichert!")
    end
    cb('ok')
end)


RegisterNUICallback('showRank', function(data, cb)
    local rank = data.rank or "ADMIN"
    local playerId = PlayerId()
    rankPlayers[playerId] = {rank = rank, timer = 999999} 
    cb('ok')
end)


RegisterNUICallback('hideRank', function(_, cb)
    local playerId = PlayerId()
    rankPlayers[playerId] = nil
    cb('ok')
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local playerPed = PlayerPedId()
        for id, info in pairs(rankPlayers) do
            local ped = PlayerPedId() -- nur für sich selbst
            if ped and DoesEntityExist(ped) then
                local coords = GetEntityCoords(ped)
                DrawText3D(coords.x, coords.y, coords.z + 1.0, info.rank)
            end
        end
    end
end)


function DrawText3D(x, y, z, text)
    local onScreen,_x,_y = World3dToScreen2d(x, y, z)
    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 0, 0, 215)
        SetTextCentre(1)
        SetTextEntry("STRING")
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end
